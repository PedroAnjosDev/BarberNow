/**
 * 
 */
/**
 * 
 */
module barbernow {
}